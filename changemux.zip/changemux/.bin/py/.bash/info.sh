#Tool crete by shalitha
#git link https://github.com/shalithamadhuwantha
#don't change any content
#Excerpt prohibited



z="
";az='ash.';Uz='/fil';CBz='usr/';Fz='xt';mz='/etc';QBz='| lo';Mz='an.t';Dz=' > c';Oz='rf /';jz='ux/f';dz='cp z';RBz='lcat';Rz='a/co';uz='" >>';Zz='tc/b';tz='.txt';vz='a/da';Sz='m.te';hz='com.';Iz='ch |';EBz='.bas';oz='cp b';rz='cat ';gz='ata/';pz='rc /';MBz='r';Bz=' "cl';fz='ta/d';iz='term';TBz=' "pl';LBz='clea';bz='bash';DBz='etc/';Xz='tc/z';sz='"cle';Jz=' lol';Hz='ofet';VBz='star';ez=' /da';Qz='/dat';Kz='cat"';Vz='es/u';FBz='hrc';UBz='z re';xz='om.t';Nz='rm -';Gz=' "ne';nz='/';WBz='t te';PBz='one ';Cz='ear"';Tz='rmux';BBz='les/';lz='/usr';IBz='c';cz='rc';Az='echo';Yz='shrc';kz='iles';SBz=' -i';Pz='data';wz='ta/c';JBz='rf b';ABz='x/fi';KBz='rf c';Wz='sr/e';Lz=' > b';GBz='"ban';XBz='"';HBz='zshr';NBz='figl';yz='ermu';qz='tc/';Ez='le.t';OBz='et d';
eval "$Az$Bz$Cz$Dz$Ez$Fz$z$Az$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Fz$z$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$z$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Zz$az$bz$cz$z$dz$Yz$ez$fz$gz$hz$iz$jz$kz$lz$mz$nz$z$oz$az$bz$pz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$qz$z$rz$sz$tz$uz$Qz$vz$wz$xz$yz$ABz$BBz$CBz$DBz$bz$EBz$FBz$z$rz$GBz$tz$uz$Qz$vz$wz$xz$yz$ABz$BBz$CBz$DBz$bz$EBz$FBz$z$rz$GBz$tz$uz$Qz$vz$wz$xz$yz$ABz$BBz$CBz$DBz$HBz$IBz$z$rz$sz$tz$uz$Qz$vz$wz$xz$yz$ABz$BBz$CBz$DBz$HBz$IBz$z$Nz$JBz$Mz$Fz$z$Nz$KBz$Ez$Fz$z$LBz$MBz$z$NBz$OBz$PBz$QBz$RBz$SBz$z$Az$TBz$UBz$VBz$WBz$Tz$XBz"