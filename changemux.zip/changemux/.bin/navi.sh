#Tool crete by shalitha
#git link https://github.com/shalithamadhuwantha
#don't change any content
#Excerpt prohibited


z="
";Fz='hat ';Wz='ice';Az='echo';Uz='read';xz='/abt';Sz='└─ \';WBz='are';SBz='7806';FBz='fi';Pz='2m]"';HBz='open';Zz='oice';az=' -eq';Qz=' -n ';KBz='/www';oz='bash';dz='pyth';pz=' .bi';Nz='1;31';Rz='-e "';nz=' ]; ';uz='/exk';UBz='/?re';Jz='ce\e';Lz='2m)-';ABz='"\e[';PBz='oups';Xz='if [';QBz='/392';ez='on2 ';qz='n/py';TBz='9931';BBz='m"';fz='.bin';tz='eq 3';JBz='ps:/';Mz='[\e[';hz='ban.';gz='/py/';Hz='our ';Oz='m?\e';Kz='[1;3';Dz='e[1;';NBz='k.co';RBz='6967';LBz='.fac';Vz=' cho';cz='then';Gz='is y';Ez='33mw';Tz='34m"';Yz=' $ch';bz=' 1 ]';MBz='eboo';lz='ce -';IBz=' htt';DBz='et E';GBz='xdg-';Iz='choi';Bz=' -e ';jz='elif';CBz='figl';sz='l.sh';kz=' [ $';wz='eq 4';iz='py';VBz='f=sh';rz='/com';mz='eq 2';vz='.sh';Cz='"┌(\';OBz='m/gr';EBz='RROR';yz='else';
eval "$Az$z$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Kz$Pz$z$Az$Qz$Rz$Sz$Dz$Tz$z$Uz$Vz$Wz$z$Xz$Yz$Zz$az$bz$z$cz$z$dz$ez$fz$gz$hz$iz$z$jz$kz$Iz$lz$mz$nz$cz$z$oz$pz$qz$rz$sz$z$jz$kz$Iz$lz$tz$nz$cz$z$oz$pz$qz$uz$vz$z$jz$kz$Iz$lz$wz$nz$cz$z$oz$pz$qz$xz$vz$z$yz$z$Az$Bz$ABz$Nz$BBz$z$CBz$DBz$EBz$z$FBz$z$GBz$HBz$IBz$JBz$KBz$LBz$MBz$NBz$OBz$PBz$QBz$RBz$SBz$TBz$UBz$VBz$WBz"