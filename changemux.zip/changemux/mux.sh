#Tool crete by shalitha
#git link https://github.com/shalithamadhuwantha
#don't change any content
#Excerpt prohibited


z="
";Xz='ou w';Az='clea';pz='pyth';Sz=' -n ';mz='then';bz='nue?';Rz='akku';nz='et s';oz='h';Vz=';31m';Wz='do y';HBz='RROR';FBz='m"';sz='.py';lz='y ]';Bz='r';cz=' [y/';az='onti';ABz='hen';Hz='OLOP';dz='n]  ';Oz='NDRO';Uz='\e[1';Jz='"';DBz='else';hz='if [';xz='= n ';Nz='et A';iz=' $ch';Ez='"\e[';Lz='m "';fz=' cho';EBz='1;31';Fz='1;33';qz='on2 ';rz='.mux';Zz='to c';Iz=' BY ';Mz='figl';jz='oice';Gz='mDEV';ez='read';Dz=' -e ';gz='ice';GBz='et E';yz=']; t';uz=' [ $';Cz='echo';tz='elif';kz=' == ';BBz='logo';Kz='1;32';Qz='et y';Pz='ID';CBz='ut';vz='choi';wz='ce =';Yz='ant ';IBz='fi';Tz='-e "';
eval "$Az$Bz$z$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$z$Cz$Dz$Ez$Kz$Lz$z$Mz$Nz$Oz$Pz$z$Mz$Qz$Rz$z$Cz$z$Cz$z$Cz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$Jz$z$ez$fz$gz$z$hz$iz$jz$kz$lz$z$mz$z$Mz$nz$oz$z$pz$qz$rz$sz$z$tz$uz$vz$wz$xz$yz$ABz$z$BBz$CBz$z$DBz$z$Cz$Dz$Ez$EBz$FBz$z$Mz$GBz$HBz$z$IBz"