#Tool crete by shalitha
#git link https://github.com/shalithamadhuwantha
#don't change any content
#Excerpt prohibited


z="
";Iz='mBY ';Mz='1;33';Kz='ITHA';wz='stal';hz='nano';fz='at';Bz=' "re';Uz='ade';Cz='ques';Hz='1;31';dz='gem ';lz='cows';bz='ruby';Dz='t fi';Lz='"';rz='lcat';Tz='upgr';Az='echo';xz='l.sh';Jz='SHAL';cz='1;34';uz=' \e[';ez='lolc';Ez='le"';nz=' ""';oz='et D';gz='pkg ';tz=' RUN';Qz='upda';az='1;32';Yz='figl';Oz='apt-';iz=' neo';qz='| lo';Pz='get ';Wz='inst';Gz='"\e[';kz='h';Zz='et';sz='mNoW';Nz='m"';Xz='all ';mz='ay';Sz='1;35';jz='fetc';Vz='1;36';Fz=' -e ';pz='ONE ';vz='m'\''In';Rz='te';
eval "$Az$Bz$Cz$Dz$Ez$z$Az$Fz$Gz$Hz$Iz$Jz$Kz$Lz$z$Az$Fz$Gz$Mz$Nz$z$Oz$Pz$Qz$Rz$z$Az$Fz$Gz$Sz$Nz$z$Oz$Pz$Tz$Uz$z$Az$Fz$Gz$Vz$Nz$z$Oz$Pz$Wz$Xz$Yz$Zz$z$Az$Fz$Gz$az$Nz$z$Oz$Pz$Wz$Xz$bz$z$Az$Fz$Gz$cz$Nz$z$dz$Wz$Xz$ez$fz$z$gz$Wz$Xz$hz$iz$jz$kz$z$Oz$Pz$Wz$Xz$Yz$Zz$z$Oz$Pz$Wz$Xz$lz$mz$z$Az$nz$z$Az$nz$z$Yz$oz$pz$qz$rz$z$Az$nz$z$Az$Fz$Gz$Hz$sz$tz$uz$cz$vz$wz$xz$Lz$z$Az$nz"